# -*- coding:utf-8 -*-

"""Brain Games scripts package."""
