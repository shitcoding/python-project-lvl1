# -*- coding:utf-8 -*-

"""1st shitcoding project: Brain Games."""
